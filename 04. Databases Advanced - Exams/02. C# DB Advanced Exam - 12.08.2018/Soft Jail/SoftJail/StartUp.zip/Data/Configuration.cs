﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=KIRIL-PECEV\SQLEXPRESS01;Database=SoftJail;Trusted_Connection=True";
    }
}
