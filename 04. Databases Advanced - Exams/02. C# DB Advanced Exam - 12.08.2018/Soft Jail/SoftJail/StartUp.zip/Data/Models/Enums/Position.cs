﻿namespace SoftJail.Data.Models.Enums
{
    public enum Position
    {
        Overseer = 1,
        Guard,
        Watcher,
        Labour
    }
}
